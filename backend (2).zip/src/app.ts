import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import path from 'path';
import authRoutes from './routes/auth.routes';
import productRoutes from './routes/product.routes';
import taxonomyRoutes from './routes/taxonomy.routes';
import cartRoutes from './routes/cart.routes';
import orderRoutes from './routes/order.routes';
import AdminRoutes from './routes/admin.routes';

const app = express();

app.use(cors({
  origin: ['http://localhost:4200', 'http://localhost:3000'],
  credentials: true,
}));

app.use(express.json());
app.use(cookieParser());

app.use('/images', express.static(path.join(__dirname, '../ProductImages')));

app.use('/api/admin', AdminRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/taxonomy', taxonomyRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);

const distPath = path.join(__dirname, '../../frontend/dist/frontend/browser');
app.use(express.static(distPath));

app.use((req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/images')) {
    return next();
  }
  res.sendFile(path.join(distPath, 'index.html'));
});

export default app;