import 'reflect-metadata';
import * as dotenv from 'dotenv';
dotenv.config();

import bcrypt from 'bcrypt';
import { AppDataSource } from '../data-source';
import app from './app';
import { ProductType } from './entities/ProductType';
import { Category } from './entities/Category';
import { SubCategory } from './entities/SubCategory';
import { Product } from './entities/Product';
import { User } from './entities/User';

const seedDatabase = async () => {
  const typeRepo = AppDataSource.getRepository(ProductType);
  const count = await typeRepo.count();

  if (count > 0) {
    console.log('Database already seeded, skipping...');
    return;
  }

  console.log('Seeding database...');

  const userRepo = AppDataSource.getRepository(User);
  const adminHash = await bcrypt.hash('admin123', 12);
  await userRepo.save(userRepo.create({
    name: 'Admin',
    email: 'admin@shop.com',
    passwordHash: adminHash,
    role: 'admin'
  }));

  const categoryRepo = AppDataSource.getRepository(Category);
  const subRepo = AppDataSource.getRepository(SubCategory);
  const productRepo = AppDataSource.getRepository(Product);

  const electronics = await typeRepo.save(typeRepo.create({ name: 'Electronics' }));
  const furniture = await typeRepo.save(typeRepo.create({ name: 'Furniture' }));
  const stationery = await typeRepo.save(typeRepo.create({ name: 'Stationery' }));
  const clothing = await typeRepo.save(typeRepo.create({ name: 'Clothing' }));
  const sports = await typeRepo.save(typeRepo.create({ name: 'Sports' }));

  const peripherals = await categoryRepo.save(categoryRepo.create({ name: 'Computer Peripherals', productType: electronics }));
  const monitors = await categoryRepo.save(categoryRepo.create({ name: 'Monitors & Displays', productType: electronics }));
  const audio = await categoryRepo.save(categoryRepo.create({ name: 'Audio', productType: electronics }));
  const phones = await categoryRepo.save(categoryRepo.create({ name: 'Mobile Phones', productType: electronics }));

  const keyboards = await subRepo.save(subRepo.create({ name: 'Keyboards', category: peripherals }));
  const mice = await subRepo.save(subRepo.create({ name: 'Mice', category: peripherals }));
  const webcams = await subRepo.save(subRepo.create({ name: 'Webcams', category: peripherals }));
  const screens = await subRepo.save(subRepo.create({ name: 'Screens', category: monitors }));
  const earphones = await subRepo.save(subRepo.create({ name: 'Earphones', category: audio }));
  const speakers = await subRepo.save(subRepo.create({ name: 'Speakers', category: audio }));
  const android = await subRepo.save(subRepo.create({ name: 'Android Phones', category: phones }));

  const tables = await categoryRepo.save(categoryRepo.create({ name: 'Tables', productType: furniture }));
  const seating = await categoryRepo.save(categoryRepo.create({ name: 'Seating', productType: furniture }));
  const storage = await categoryRepo.save(categoryRepo.create({ name: 'Storage', productType: furniture }));

  const desks = await subRepo.save(subRepo.create({ name: 'Desks', category: tables }));
  const dining = await subRepo.save(subRepo.create({ name: 'Dining Tables', category: tables }));
  const sofas = await subRepo.save(subRepo.create({ name: 'Sofas', category: seating }));
  const chairs = await subRepo.save(subRepo.create({ name: 'Office Chairs', category: seating }));
  const shelves = await subRepo.save(subRepo.create({ name: 'Bookshelves', category: storage }));

  const books = await categoryRepo.save(categoryRepo.create({ name: 'Books', productType: stationery }));
  const office = await categoryRepo.save(categoryRepo.create({ name: 'Office Supplies', productType: stationery }));

  const textbooks = await subRepo.save(subRepo.create({ name: 'Textbooks', category: books }));
  const selfhelp = await subRepo.save(subRepo.create({ name: 'Self Help', category: books }));
  const notebooks = await subRepo.save(subRepo.create({ name: 'Notebooks', category: office }));
  const pens = await subRepo.save(subRepo.create({ name: 'Pens & Pencils', category: office }));

  const mens = await categoryRepo.save(categoryRepo.create({ name: "Men's Wear", productType: clothing }));

  const tshirts = await subRepo.save(subRepo.create({ name: 'T-Shirts', category: mens }));
  const jeans = await subRepo.save(subRepo.create({ name: 'Jeans', category: mens }));

  const fitness = await categoryRepo.save(categoryRepo.create({ name: 'Fitness', productType: sports }));
  const outdoor = await categoryRepo.save(categoryRepo.create({ name: 'Outdoor', productType: sports }));

  const equipment = await subRepo.save(subRepo.create({ name: 'Equipment', category: fitness }));
  const yoga = await subRepo.save(subRepo.create({ name: 'Yoga', category: fitness }));
  const camping = await subRepo.save(subRepo.create({ name: 'Camping Gear', category: outdoor }));

  const products = [

    { name: 'Anker Multimedia Keyboard', description: 'Reliable full-size keyboard with quiet keys and comfortable wrist rest.', price: 1299, stock: 50, imagePath: 'default.png', subCategory: keyboards },
    { name: 'Mechanical Gaming Keyboard RGB', description: 'Premium mechanical keyboard with RGB backlighting and blue switches.', price: 4999, stock: 20, imagePath: 'default.png', subCategory: keyboards },
    { name: 'Logitech K380 Bluetooth Keyboard', description: 'Compact multi-device Bluetooth keyboard, works with up to 3 devices.', price: 3499, stock: 35, imagePath: 'default.png', subCategory: keyboards },

    { name: 'Wireless Ergonomic Mouse', description: 'Ergonomic wireless mouse with adjustable DPI up to 1600.', price: 1999, stock: 35, imagePath: 'default.png', subCategory: mice },
    { name: 'Logitech MX Master 3', description: 'Advanced wireless mouse with MagSpeed scroll and ergonomic design.', price: 8999, stock: 15, imagePath: 'default.png', subCategory: mice },

    { name: 'Logitech C920 HD Webcam', description: 'Full HD 1080p webcam with stereo audio and automatic light correction.', price: 5999, stock: 20, imagePath: 'default.png', subCategory: webcams },

    { name: 'Dell 27" Full HD Monitor', description: 'Crystal clear 27-inch Full HD IPS display with 75Hz refresh rate.', price: 14999, stock: 15, imagePath: 'default.png', subCategory: screens },
    { name: 'Samsung 24" FHD Monitor', description: '24-inch Full HD monitor with slim bezel and HDMI connectivity.', price: 9999, stock: 25, imagePath: 'default.png', subCategory: screens },
    { name: 'LG UltraWide 29" Monitor', description: '29-inch ultrawide IPS monitor perfect for multitasking.', price: 22999, stock: 10, imagePath: 'default.png', subCategory: screens },

    { name: 'OnePlus Bullets Z2', description: 'Wireless earphones with 30 hours battery, bombastic bass and quick charge.', price: 1799, stock: 60, imagePath: 'default.png', subCategory: earphones },
    { name: 'Sony WH-1000XM4 Headphones', description: 'Industry leading noise cancelling headphones with 30hr battery.', price: 19999, stock: 10, imagePath: 'default.png', subCategory: earphones },
    { name: 'boAt Rockerz 450', description: 'On-ear wireless headphone with 15 hours playback and 40mm drivers.', price: 1299, stock: 80, imagePath: 'default.png', subCategory: earphones },

    { name: 'JBL Flip 6', description: 'Portable Bluetooth speaker with JBL Pro Sound and IP67 waterproofing.', price: 9999, stock: 30, imagePath: 'default.png', subCategory: speakers },
    { name: 'boAt Stone 650', description: '10W outdoor bluetooth speaker with 7 hours playback.', price: 1999, stock: 45, imagePath: 'default.png', subCategory: speakers },

    { name: 'Redmi 12 5G', description: '5G smartphone with 50MP camera, 5000mAh battery and Snapdragon 4 Gen 2.', price: 10999, stock: 40, imagePath: 'default.png', subCategory: android },
    { name: 'Samsung Galaxy M34', description: '5G phone with 50MP triple camera, 6000mAh battery and sAMOLED display.', price: 16999, stock: 25, imagePath: 'default.png', subCategory: android },
    { name: 'OnePlus Nord CE 3 Lite', description: '5G smartphone with 108MP camera and 67W SUPERVOOC charging.', price: 17999, stock: 20, imagePath: 'default.png', subCategory: android },

    { name: 'Modern Study Desk', description: 'Minimalist study desk with built-in cable management and side drawer.', price: 8999, stock: 12, imagePath: 'default.png', subCategory: desks },
    { name: 'Foldable Laptop Table', description: 'Portable foldable table with adjustable height, ideal for work from home.', price: 2499, stock: 30, imagePath: 'default.png', subCategory: desks },
    { name: 'Standing Desk Converter', description: 'Height adjustable desk converter to switch between sitting and standing.', price: 12999, stock: 8, imagePath: 'default.png', subCategory: desks },

    { name: 'Solid Wood Dining Table', description: 'Elegant solid oak dining table that seats 6 comfortably.', price: 24999, stock: 8, imagePath: 'default.png', subCategory: dining },
    { name: '4-Seater Glass Dining Table', description: 'Modern tempered glass top dining table with metal legs.', price: 15999, stock: 10, imagePath: 'default.png', subCategory: dining },

    { name: 'L-Shape Comfort Sofa', description: 'Premium L-shaped sofa with high-density foam cushions.', price: 34999, stock: 5, imagePath: 'default.png', subCategory: sofas },
    { name: '3-Seater Fabric Sofa', description: 'Comfortable 3-seater sofa in premium fabric with wooden legs.', price: 19999, stock: 8, imagePath: 'default.png', subCategory: sofas },

    { name: 'Ergonomic Office Chair', description: 'Adjustable office chair with lumbar support and breathable mesh back.', price: 9999, stock: 20, imagePath: 'default.png', subCategory: chairs },
    { name: 'Gaming Chair RGB', description: 'Racing style gaming chair with recline, armrests and lumbar cushion.', price: 14999, stock: 12, imagePath: 'default.png', subCategory: chairs },

    { name: '5-Tier Bookshelf', description: 'Sturdy 5-tier open bookshelf in walnut finish, holds up to 150kg.', price: 6999, stock: 15, imagePath: 'default.png', subCategory: shelves },
    { name: 'Floating Wall Shelves Set', description: 'Set of 3 floating wooden wall shelves with invisible mounting.', price: 1999, stock: 40, imagePath: 'default.png', subCategory: shelves },

    { name: 'Science for Kids Grade 5', description: 'Comprehensive science textbook for grade 5 with illustrations.', price: 499, stock: 75, imagePath: 'default.png', subCategory: textbooks },
    { name: 'Class 10 Mathematics NCERT', description: 'Official NCERT Mathematics textbook for Class 10.', price: 299, stock: 100, imagePath: 'default.png', subCategory: textbooks },
    { name: 'Class 12 Physics NCERT', description: 'Official NCERT Physics textbook for Class 12 Part 1 & 2.', price: 399, stock: 100, imagePath: 'default.png', subCategory: textbooks },

    { name: 'Atomic Habits', description: 'Easy and proven ways to build good habits and break bad ones by James Clear.', price: 399, stock: 100, imagePath: 'default.png', subCategory: selfhelp },
    { name: 'The Psychology of Money', description: 'Timeless lessons on wealth, greed and happiness by Morgan Housel.', price: 349, stock: 80, imagePath: 'default.png', subCategory: selfhelp },
    { name: 'Deep Work', description: 'Rules for focused success in a distracted world by Cal Newport.', price: 329, stock: 60, imagePath: 'default.png', subCategory: selfhelp },

    { name: 'A5 Spiral Notebook Pack (5)', description: 'Pack of 5 high-quality A5 spiral notebooks with 200 pages each.', price: 599, stock: 200, imagePath: 'default.png', subCategory: notebooks },
    { name: 'Classmate Notebook 6-Pack', description: '6 single-line classmate notebooks, 172 pages each.', price: 299, stock: 150, imagePath: 'default.png', subCategory: notebooks },

    { name: 'Parker Jotter Ball Pen', description: 'Classic stainless steel ballpoint pen with medium point.', price: 499, stock: 100, imagePath: 'default.png', subCategory: pens },
    { name: 'Staedtler Pencil Set (12)', description: 'Set of 12 HB graphite pencils, ideal for writing and sketching.', price: 199, stock: 150, imagePath: 'default.png', subCategory: pens },

    { name: 'Men\'s Cotton Round Neck T-Shirt', description: 'Pure cotton round neck t-shirt, available in multiple colours.', price: 399, stock: 100, imagePath: 'default.png', subCategory: tshirts },
    { name: 'Men\'s Polo T-Shirt', description: 'Classic polo collar t-shirt with breathable fabric.', price: 599, stock: 80, imagePath: 'default.png', subCategory: tshirts },
    { name: 'Men\'s Graphic Oversized Tee', description: 'Oversized graphic print t-shirt in 100% cotton.', price: 699, stock: 60, imagePath: 'default.png', subCategory: tshirts },

    { name: 'Men\'s Slim Fit Jeans', description: 'Slim fit stretchable jeans in dark blue wash.', price: 1299, stock: 50, imagePath: 'default.png', subCategory: jeans },
    { name: 'Men\'s Regular Fit Jeans', description: 'Classic regular fit jeans with 5-pocket styling.', price: 999, stock: 60, imagePath: 'default.png', subCategory: jeans },

    { name: 'Adjustable Dumbbell Set (10kg)', description: 'Pair of adjustable dumbbells up to 10kg each with quick lock.', price: 2999, stock: 30, imagePath: 'default.png', subCategory: equipment },
    { name: 'Resistance Bands Set', description: 'Set of 5 resistance bands of varying strengths for home workouts.', price: 699, stock: 80, imagePath: 'default.png', subCategory: equipment },
    { name: 'Skipping Rope', description: 'Adjustable speed skipping rope with ball-bearing handles.', price: 299, stock: 100, imagePath: 'default.png', subCategory: equipment },

    { name: 'Yoga Mat 6mm', description: 'Non-slip TPE yoga mat, 6mm thick with carrying strap.', price: 799, stock: 60, imagePath: 'default.png', subCategory: yoga },
    { name: 'Yoga Block Set (2)', description: 'Pair of high-density foam yoga blocks for balance and flexibility.', price: 499, stock: 50, imagePath: 'default.png', subCategory: yoga },

    { name: '2-Person Camping Tent', description: 'Lightweight waterproof tent with easy setup, fits 2 people.', price: 3999, stock: 15, imagePath: 'default.png', subCategory: camping },
    { name: 'Trekking Backpack 50L', description: '50-litre water-resistant trekking backpack with hip support.', price: 2499, stock: 20, imagePath: 'default.png', subCategory: camping },
  ];

  for (const p of products) {
    await productRepo.save(productRepo.create(p));
  }

  console.log(`Seeding complete! ${products.length} products added across 5 types.`);
};

const PORT = parseInt(process.env.PORT || '3000');

AppDataSource.initialize()
  .then(async () => {
    console.log('Database connected');
    await AppDataSource.runMigrations();  
    console.log('Migrations ran successfully');
    await seedDatabase();
    app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
  })
  .catch((error) => {
    console.error('DB connection error:', error);
    process.exit(1);
  });