import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import * as adminController from '../controllers/adminController';
import { authenticate, requireRole } from '../middleware/authMiddleware';
import upload from '../middleware/upload';

const router = Router();

router.use(authenticate);
router.use(requireRole('admin'));

const handleValidation = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: errors.array()[0].msg });
  }
  next();
};

router.get('/products', adminController.getAllProducts);

router.post('/products', upload.single('image'), [
  body('name').trim().notEmpty().withMessage('Product name is required'),
  body('price').isFloat({ min: 0 }).withMessage('Valid price is required'),
  body('stock').isInt({ min: 0 }).withMessage('Valid stock is required'),
  body('subCategoryId').isInt({ min: 1 }).withMessage('Sub-category is required'),
], handleValidation, adminController.createProduct);

router.put('/products/:id', upload.single('image'), adminController.updateProduct);
router.delete('/products/:id', adminController.deleteProduct);

router.get('/customers', adminController.getAllCustomers);
router.patch('/customers/:id/lock', adminController.toggleLockCustomer);

router.get('/orders', adminController.getAllOrders);
router.get('/orders/:id', adminController.getOrderDetail);

export default router;