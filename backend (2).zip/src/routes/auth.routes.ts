import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import * as authController from '../controllers/authController';
import { authenticate } from '../middleware/authMiddleware';

const router = Router();

const handleValidation = (req: any, res: any, next: any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ message: errors.array()[0].msg });
    }
    next();
};

router.post('/register', [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
], handleValidation, authController.register);

router.post('/login', [
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
    body('password').notEmpty().withMessage('Password is required'),
], handleValidation, authController.login);

router.post('/logout', authenticate, authController.logout);

router.post('/forgot-password', [
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
], handleValidation, authController.forgotPassword);

router.post('/reset-password', [
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
    body('code').notEmpty().withMessage('Code is required'),
    body('newPassword').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
], handleValidation, authController.resetPassword);

router.get('/me', authenticate, authController.getMe);
router.put('/profile', authenticate, [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
], handleValidation, authController.updateProfile);

router.put('/change-password', authenticate, [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
], handleValidation, authController.changePassword);

export default router;