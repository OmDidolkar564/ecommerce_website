import fs from 'fs';
import path from 'path';
import csv from 'csv-parser';
import axios from 'axios';
import { AppDataSource } from '../data-source';
import { Product } from '../src/entities/Product';
import { ProductType } from '../src/entities/ProductType';
import { Category } from '../src/entities/Category';
import { SubCategory } from '../src/entities/SubCategory';

// ---------- HELPERS ----------

function cleanPrice(priceStr: string): number {
  if (!priceStr) return 0;
  return parseFloat(priceStr.replace(/[^0-9.]/g, '')) || 0;
}

async function downloadImage(url: string, filename: string): Promise<string | null> {
  try {
    // Ensure the directory exists
    const dir = path.join(process.cwd(), 'ProductImages');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);

    const filepath = path.join(dir, filename);
    const response = await axios({
      url,
      responseType: 'stream',
      timeout: 10000 // 10 seconds timeout
    });

    return new Promise((resolve, reject) => {
      const writer = fs.createWriteStream(filepath);
      response.data.pipe(writer);
      writer.on('finish', () => resolve(filename)); // Return just the filename
      writer.on('error', (err) => {
        console.error("Write Error:", err.message);
        reject(null);
      });
    });
  } catch (err: any) {
    console.error(`Could not download image: ${url} - ${err.message}`);
    return null;
  }
}

// ---------- MAIN PROCESS ----------

async function processRow(row: any, countRef: { count: number }) {
  try {
    const name = row.name?.trim();
    const typeName = row.main_category?.trim();
    const subCategoryName = row.sub_category?.trim();

    if (!name || !typeName || !subCategoryName) return;

    const price = cleanPrice(row.discount_price);

    const typeRepo = AppDataSource.getRepository(ProductType);
    const categoryRepo = AppDataSource.getRepository(Category);
    const subRepo = AppDataSource.getRepository(SubCategory);
    const productRepo = AppDataSource.getRepository(Product);

    // 1. TYPE
    let type = await typeRepo.findOne({ where: { name: typeName } });
    if (!type) {
      type = await typeRepo.save(typeRepo.create({ name: typeName }));
    }

    // 2. CATEGORY
    const categoryName = typeName + "_general";
    let category = await categoryRepo.findOne({
      where: { name: categoryName, productType: { id: type.id } }
    });
    if (!category) {
      category = await categoryRepo.save(categoryRepo.create({ name: categoryName, productType: type }));
    }

    // 3. SUBCATEGORY
    let subCategory = await subRepo.findOne({
      where: { name: subCategoryName, category: { id: category.id } }
    });
    if (!subCategory) {
      subCategory = await subRepo.save(subRepo.create({ name: subCategoryName, category }));
    }

    // 4. DUPLICATE CHECK
    const existing = await productRepo.findOne({ where: { name } });
    if (existing) return;

    // 5. DOWNLOAD IMAGE
    let finalImagePath = 'default.jpg';
    if (row.image && row.image.startsWith('http')) {
      // Create a unique name: e.g., product_1700000000_542.jpg
      const fileName = `product_${Date.now()}_${Math.floor(Math.random() * 1000)}.jpg`;
      const downloadedFile = await downloadImage(row.image, fileName);
      if (downloadedFile) {
        finalImagePath = downloadedFile;
      }
    }

    // 6. INSERT PRODUCT
    await productRepo.save(productRepo.create({
      name,
      description: name,
      price,
      stock: 20,
      imagePath: finalImagePath, // Storing only the filename "product_xyz.jpg"
      subCategory
    }));

    countRef.count++;
    console.log(`[${countRef.count}] Imported: ${name.substring(0, 30)}...`);

  } catch (err: any) {
    console.error("Row Error:", err.message);
  }
}

// ---------- RUN SCRIPT ----------

async function run() {
  try {
    await AppDataSource.initialize();
    console.log("🗄️ Connected to SQLite");

    const dataFolder = path.join(process.cwd(), 'data');
    const files = fs.readdirSync(dataFolder).filter(f => f.endsWith('.csv'));

    const countRef = { count: 0 };

    for (const file of files) {
      const filePath = path.join(dataFolder, file);
      const rows: any[] = [];

      await new Promise<void>((resolve, reject) => {
        fs.createReadStream(filePath)
          .pipe(csv())
          .on('data', (row) => rows.push(row))
          .on('end', async () => {
            // Processing one-by-one is crucial for SQLite + Image Downloading
            for (const row of rows) {
              await processRow(row, countRef);
            }
            resolve();
          })
          .on('error', reject);
      });
    }

    console.log(`\n✅ Finished! ${countRef.count} products added with local images.`);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();