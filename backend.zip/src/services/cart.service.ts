import { AppDataSource } from '../../data-source';
import { CartItem } from '../entities/CartItem';
import { Product } from '../entities/Product';

const cartRepo = () => AppDataSource.getRepository(CartItem);
const productRepo = () => AppDataSource.getRepository(Product);

export const getCart = async (userId: number) => {
  return cartRepo().find({
    where: { user: { id: userId } },
    relations: ['product'],
  });
};

export const addToCart = async (userId: number, productId: number, quantity: number) => {
  const product = await productRepo().findOne({ where: { id: productId } });
  if (!product) throw new Error('Product not found');
  if (product.stock < quantity) throw new Error('Not enough stock');

  const existing = await cartRepo().findOne({
    where: { user: { id: userId }, product: { id: productId } },
  });

  if (existing) {
    existing.quantity += quantity;
    return cartRepo().save(existing);
  }

  const item = cartRepo().create({
    user: { id: userId },
    product: { id: productId },
    quantity,
  });
  return cartRepo().save(item);
};

export const updateQuantity = async (userId: number, itemId: number, quantity: number) => {
  const item = await cartRepo().findOne({
    where: { id: itemId, user: { id: userId } },
  });
  if (!item) throw new Error('Cart item not found');
  if (quantity < 1) throw new Error('Quantity must be at least 1');
  item.quantity = quantity;
  return cartRepo().save(item);
};

export const removeFromCart = async (userId: number, itemId: number) => {
  const item = await cartRepo().findOne({
    where: { id: itemId, user: { id: userId } },
  });
  if (!item) throw new Error('Cart item not found');
  return cartRepo().remove(item);
};

export const clearCart = async (userId: number) => {
  const items = await cartRepo().find({ where: { user: { id: userId } } });
  return cartRepo().remove(items);
};