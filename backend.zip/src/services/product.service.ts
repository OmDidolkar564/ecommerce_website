import { AppDataSource } from '../../data-source';
import { Product } from '../entities/Product';
import { ProductType } from '../entities/ProductType';
import { Category } from '../entities/Category';
import { SubCategory } from '../entities/SubCategory';


export const getAllTypes = async () => {
    return AppDataSource.getRepository(ProductType).find();
};

export const getCategoriesByType = async (typeId: number) => {
    return AppDataSource.getRepository(Category).find({
        where: { productType: { id: typeId } },
        relations: ['productType'],
    });
};

export const getSubCategoriesByCategory = async (categoryId: number) => {
    return AppDataSource.getRepository(SubCategory).find({
        where: { category: { id: categoryId } },
        relations: ['category'],
    });
};


export const getProducts = async (query: {
    search?: string;
    typeId?: number;
    categoryId?: number;
    subCategoryId?: number;
    minPrice?: number;
    maxPrice?: number;
    inStock?: boolean;
    page?: number;
    limit?: number;
}) => {
    const page = query.page || 1;
    const limit = query.limit || 12;
    const skip = (page - 1) * limit;

    const qb = AppDataSource.getRepository(Product)
        .createQueryBuilder('product')
        .leftJoinAndSelect('product.subCategory', 'subCategory')
        .leftJoinAndSelect('subCategory.category', 'category')
        .leftJoinAndSelect('category.productType', 'productType');

    if (query.search) {
        qb.andWhere(
            '(LOWER(product.name) LIKE LOWER(:search) OR LOWER(product.description) LIKE LOWER(:search))',
            { search: `%${query.search}%` }
        );
    }

    if (query.typeId) {
        qb.andWhere('productType.id = :typeId', { typeId: query.typeId });
    }

    if (query.categoryId) {
        qb.andWhere('category.id = :categoryId', { categoryId: query.categoryId });
    }

    if (query.subCategoryId) {
        qb.andWhere('subCategory.id = :subCategoryId', { subCategoryId: query.subCategoryId });
    }

    if (query.minPrice !== undefined) {
        qb.andWhere('product.price >= :minPrice', { minPrice: query.minPrice });
    }

    if (query.maxPrice !== undefined) {
        qb.andWhere('product.price <= :maxPrice', { maxPrice: query.maxPrice });
    }

    if (query.inStock === true) {
  qb.andWhere('product.stock > 0');
}

    const total = await qb.getCount();
    qb.skip(skip).take(limit);

    const products = await qb.getMany();

    return {
        products, total, page, limit, totalPages: Math.ceil(total / limit),
    };
};

 export const getProductById = async (id: number) => {
    const product = await AppDataSource.getRepository(Product).findOne({
        where: { id },
        relations: ['subCategory', 'subCategory.category', 'subCategory.category.productType'],
    });
    if (!product) throw new Error('Product not found');
    return product;
};