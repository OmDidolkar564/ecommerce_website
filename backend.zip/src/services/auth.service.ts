import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { AppDataSource } from '../../data-source';
import { User } from '../entities/User';
import { ResetCode } from '../entities/Resetcode';
import sessionStore from '../middleware/sessionStore';

const userRepo = () => AppDataSource.getRepository(User);
const resetRepo = () => AppDataSource.getRepository(ResetCode);

export const registerUser = async (name: string, email: string, password: string) => {
  const existing = await userRepo().findOne({ where: { email } });
  if (existing) throw new Error('Email already registered');

  const passwordHash = await bcrypt.hash(password, 12);
  const user = userRepo().create({ name, email, passwordHash, role: 'customer' });
  await userRepo().save(user);
  return { message: 'Registration successful' };
};

export const loginUser = async (email: string, password: string) => {
  const user = await userRepo().findOne({ where: { email } });
  if (!user) throw new Error('Invalid email or password');
  if (user.isLocked) throw new Error('Account is locked');

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) throw new Error('Invalid email or password');

  const sessionId = uuidv4();
  sessionStore.set(sessionId, { userId: user.id, role: user.role });

  const token = jwt.sign(
    { userId: user.id, role: user.role, sessionId },
    process.env.JWT_SECRET as string,
    { expiresIn: '7d' }
  );

  return { token, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
};

export const logoutUser = (sessionId: string) => {
  sessionStore.delete(sessionId);
};

export const forgotPassword = async (email: string) => {
  const user = await userRepo().findOne({ where: { email } });
  if (!user) throw new Error('No account found with that email');

  // Invalidate any existing unused codes for this user
  await resetRepo()
    .createQueryBuilder()
    .update(ResetCode)
    .set({ used: true })
    .where('userId = :id AND used = false', { id: user.id })
    .execute();

  // Generate a 6-digit code
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  const resetCode = resetRepo().create({ code, expiresAt, used: false, user });
  await resetRepo().save(resetCode);

  return { code }; // Returned to frontend to display on screen (mock flow)
};

export const resetPassword = async (email: string, code: string, newPassword: string) => {
  const user = await userRepo().findOne({ where: { email } });
  if (!user) throw new Error('Invalid request');

  const resetCode = await resetRepo().findOne({
    where: { code, used: false },
    relations: ['user'],
  });

  if (!resetCode || resetCode.user.id !== user.id) {
    throw new Error('Invalid or expired code');
  }

  if (new Date() > resetCode.expiresAt) {
    throw new Error('Code has expired');
  }

  const passwordHash = await bcrypt.hash(newPassword, 12);
  await userRepo().update(user.id, { passwordHash });
  await resetRepo().update(resetCode.id, { used: true });

  return { message: 'Password reset successful' };
};

export const updateProfile = async (userId: number, name: string, email: string) => {
  const user = await userRepo().findOne({ where: { id: userId } });
  if (!user) throw new Error('User not found');

  const emailExists = await userRepo().findOne({ where: { email } });
  if (emailExists && emailExists.id !== userId) {
    throw new Error('Email already in use by another account');
  }

  user.name = name;
  user.email = email;
  await userRepo().save(user);

  return { id: user.id, name: user.name, email: user.email, role: user.role };
};

export const changePassword = async (userId: number, currentPassword: string, newPassword: string) => {
  const user = await userRepo().findOne({ where: { id: userId } });
  if (!user) throw new Error('User not found');

  const valid = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!valid) throw new Error('Current password is incorrect');

  user.passwordHash = await bcrypt.hash(newPassword, 12);
  await userRepo().save(user);

  return { message: 'Password changed successfully' };
};