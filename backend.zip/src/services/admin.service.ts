import { AppDataSource } from '../../data-source';
import { Product } from '../entities/Product';
import { User } from '../entities/User';
import { Order } from '../entities/Order';
import { SubCategory } from '../entities/SubCategory';
import sessionStore from '../middleware/sessionStore';

const productRepo = () => AppDataSource.getRepository(Product);
const userRepo = () => AppDataSource.getRepository(User);
const orderRepo = () => AppDataSource.getRepository(Order);

export const createProduct = async (data: {
  name: string;
  description: string;
  price: number;
  stock: number;
  subCategoryId: number;
  imagePath?: string;
}) => {
  const subCategory = await AppDataSource.getRepository(SubCategory).findOne({
    where: { id: data.subCategoryId },
  });
  if (!subCategory) throw new Error('SubCategory not found');

  const product = productRepo().create({
    name: data.name,
    description: data.description,
    price: data.price,
    stock: data.stock,
    imagePath: data.imagePath || null,
    subCategory,
  });

  return productRepo().save(product);
};

export const updateProduct = async (
  id: number,
  data: {
    name?: string;
    description?: string;
    price?: number;
    stock?: number;
    subCategoryId?: number;
    imagePath?: string;
  }
) => {
  const product = await productRepo().findOne({
    where: { id },
    relations: ['subCategory'],
  });
  if (!product) throw new Error('Product not found');

  if (data.name) product.name = data.name;
  if (data.description) product.description = data.description;
  if (data.price !== undefined) product.price = data.price;
  if (data.stock !== undefined) product.stock = data.stock;
  if (data.imagePath) product.imagePath = data.imagePath;

  if (data.subCategoryId) {
    const subCategory = await AppDataSource.getRepository(SubCategory).findOne({
      where: { id: data.subCategoryId },
    });
    if (!subCategory) throw new Error('SubCategory not found');
    product.subCategory = subCategory;
  }

  return productRepo().save(product);
};

export const deleteProduct = async (id: number) => {
  const product = await productRepo().findOne({ where: { id } });
  if (!product) throw new Error('Product not found');
  await productRepo().remove(product);
  return { message: 'Product deleted successfully' };
};

export const getAllProducts = async () => {
  return productRepo().find({
    relations: ['subCategory', 'subCategory.category', 'subCategory.category.productType'],
  });
};

export const getAllCustomers = async () => {
  return userRepo().find({
    where: { role: 'customer' },
    select: ['id', 'name', 'email', 'isLocked', 'createdAt'],
  });
};

export const toggleLockCustomer = async (customerId: number) => {
  const user = await userRepo().findOne({ where: { id: customerId, role: 'customer' } });
  if (!user) throw new Error('Customer not found');

  user.isLocked = !user.isLocked;
  await userRepo().save(user);

  if (user.isLocked) {
    for (const [sessionId, session] of sessionStore.entries()) {
      if (session.userId === customerId) {
        sessionStore.delete(sessionId);
      }
    }
  }

  return {
    message: user.isLocked ? 'Customer locked successfully' : 'Customer unlocked successfully',
    isLocked: user.isLocked,
  };
};

export const getAllOrders = async () => {
  return orderRepo().find({
    relations: ['user', 'orderItems', 'orderItems.product'],
    order: { placedAt: 'DESC' },
  });
};

export const getOrderDetail = async (orderId: number) => {
  const order = await orderRepo().findOne({
    where: { id: orderId },
    relations: ['user', 'orderItems', 'orderItems.product'],
  });
  if (!order) throw new Error('Order not found');
  return order;
};