import { AppDataSource } from '../../data-source'
import { Order } from '../entities/Order';
import { OrderItem } from '../entities/OrderItem';
import { CartItem } from '../entities/CartItem';

export const placeOrder = async (userId: number, paymentMethod: string) => {
  const cartRepo = AppDataSource.getRepository(CartItem);
  const orderRepo = AppDataSource.getRepository(Order);
  const orderItemRepo = AppDataSource.getRepository(OrderItem);

  const cartItems = await cartRepo.find({
    where: { user: { id: userId } },
    relations: ['product'],
  });

  if (cartItems.length === 0) {
    throw new Error('Cart is empty');
  }

  let totalAmount = 0;
  for (const item of cartItems) {
    if (item.product.stock < item.quantity) {
      throw new Error(`Not enough stock for ${item.product.name}`);
    }
    totalAmount += item.product.price * item.quantity;
  }

  const order = orderRepo.create({
    user: { id: userId },
    paymentMethod,
    totalAmount,
  });
  await orderRepo.save(order);

  for (const item of cartItems) {
    const orderItem = orderItemRepo.create({
      order,
      product: item.product,
      quantity: item.quantity,
      priceAtPurchase: item.product.price,
    });
    await orderItemRepo.save(orderItem);

    await AppDataSource.getRepository('Product')
      .createQueryBuilder()
      .update()
      .set({ stock: () => `stock - ${item.quantity}` })
      .where('id = :id', { id: item.product.id })
      .execute();
  }

  await cartRepo.remove(cartItems);

  return orderRepo.findOne({
    where: { id: order.id },
    relations: ['orderItems', 'orderItems.product'],
  });
};

export const getMyOrders = async (userId: number) => {
  return AppDataSource.getRepository(Order).find({
    where: { user: { id: userId } },
    relations: ['orderItems', 'orderItems.product'],
    order: { placedAt: 'DESC' },
  });
};

export const getOrderById = async (userId: number, orderId: number) => {
  const order = await AppDataSource.getRepository(Order).findOne({
    where: { id: orderId, user: { id: userId } },
    relations: ['orderItems', 'orderItems.product'],
  });
  if (!order) throw new Error('Order not found');
  return order;
};