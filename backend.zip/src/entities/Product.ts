import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';
import { SubCategory } from './SubCategory';
import { CartItem } from './CartItem';
import { OrderItem } from './OrderItem';


@Entity()
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'real' })
  price: number;

  @Column({ default: 0 })
  stock: number;

  @Column({ nullable: true })
  imagePath: string;

  @ManyToOne(() => SubCategory, (sub) => sub.products, { onDelete: 'SET NULL', nullable: true })
  subCategory: SubCategory;

  @OneToMany(() => CartItem, (item) => item.product)
  cartItems: CartItem[];

  @OneToMany(() => OrderItem, (item) => item.product)
  orderItems: OrderItem[];
}