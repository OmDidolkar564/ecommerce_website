import { Router } from 'express';
import * as adminController from '../controllers/adminController';
import { authenticate, requireRole } from '../middleware/authMiddleware';
import upload from '../middleware/upload';

const router = Router();

router.use(authenticate);
router.use(requireRole('admin'));

router.get('/products', adminController.getAllProducts);
router.post('/products', upload.single('image'), adminController.createProduct);
router.put('/products/:id', upload.single('image'), adminController.updateProduct);
router.delete('/products/:id', adminController.deleteProduct);

router.get('/customers', adminController.getAllCustomers);
router.patch('/customers/:id/lock', adminController.toggleLockCustomer);

router.get('/orders', adminController.getAllOrders);
router.get('/orders/:id', adminController.getOrderDetail);

export default router;