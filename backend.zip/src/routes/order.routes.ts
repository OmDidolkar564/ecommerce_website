import { Router } from 'express';
import * as orderController from '../controllers/orderController';
import { authenticate } from '../middleware/authMiddleware';

const router = Router();

router.use(authenticate);

router.post('/', orderController.placeOrder);
router.get('/', orderController.getMyOrders);
router.get('/:orderId', orderController.getOrderById);

export default router;