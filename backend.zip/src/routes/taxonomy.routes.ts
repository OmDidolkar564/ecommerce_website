import { Router } from 'express';
import * as productController from '../controllers/productController';

const router = Router();

router.get('/types', productController.getTypes);
router.get('/categories/:typeId', productController.getCategories);
router.get('/subcategories/:categoryId', productController.getSubCategories);

export default router;