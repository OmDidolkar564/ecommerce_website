import { Router } from 'express';
import * as cartController from '../controllers/cartController';
import { authenticate } from '../middleware/authMiddleware';

const router = Router();

router.use(authenticate);

router.get('/', cartController.getCart);
router.post('/', cartController.addToCart);
router.put('/:itemId', cartController.updateQuantity);
router.delete('/:itemId', cartController.removeFromCart);

export default router;