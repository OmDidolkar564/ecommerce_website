import { Request, Response } from 'express';
import * as productService from '../services/product.service';

export const getTypes = async (req: Request, res: Response) => {
    try {
        const types = await productService.getAllTypes();
        return res.json(types);
    } catch (err: any) {
        return res.status(500).json({ message: 'Server error' });
    }
};

export const getCategories = async (req: Request, res: Response) => {
    try {
        const typeId = parseInt(req.params.typeId as string);
        const categories = await productService.getCategoriesByType(typeId);
        return res.json(categories);
    } catch (err: any) {
        return res.status(500).json({ message: 'Server error' });
    }
};


export const getSubCategories = async (req: Request, res: Response) => {
    try {
        const categoryId = parseInt(req.params.categoryId as string);
        const subCategories = await productService.getSubCategoriesByCategory(categoryId);
        return res.json(subCategories);
    } catch (err: any) {
        return res.status(500).json({ message: 'Server error' });
    }
};


export const getProducts = async (req: Request, res: Response) => {
    try {
        const {
            search,
            typeId,
            categoryId,
            subCategoryId,
            minPrice,
            maxPrice,
            inStock,
            page,
            limit,
        } = req.query;

        const result = await productService.getProducts({
            search: search as string || undefined,
            typeId: typeId ? parseInt(typeId as string) : undefined,
            categoryId: categoryId ? parseInt(categoryId as string) : undefined,
            subCategoryId: subCategoryId ? parseInt(subCategoryId as string) : undefined,
            minPrice: minPrice ? parseFloat(minPrice as string) : undefined,
            maxPrice: maxPrice ? parseFloat(maxPrice as string) : undefined,
            inStock: inStock === 'true' ? true : false,  // only true if explicitly passed
            page: page ? parseInt(page as string) : 1,
            limit: limit ? parseInt(limit as string) : 12,
        });

        return res.json(result);
    } catch (err: any) {
        return res.status(500).json({ message: err.message });
    }
};

export const getProductById = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id as string);
        const product = await productService.getProductById(id);
        return res.json(product);
    } catch (err: any) {
        return res.status(404).json({ message: err.message });
    }
};