import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
import * as cartService from '../services/cart.service';

export const getCart = async (req: AuthRequest, res: Response) => {
  try {
    const items = await cartService.getCart(req.user!.userId);
    return res.json(items);
  } catch (err: any) {
    return res.status(500).json({ message: err.message });
  }
};

export const addToCart = async (req: AuthRequest, res: Response) => {
  try {
    const { productId, quantity } = req.body;
    if (!productId || !quantity) {
      return res.status(400).json({ message: 'productId and quantity are required' });
    }
    const item = await cartService.addToCart(req.user!.userId, productId, quantity);
    return res.status(201).json(item);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const updateQuantity = async (req: AuthRequest, res: Response) => {
  try {
    const itemId = parseInt(req.params.itemId as string);
    const { quantity } = req.body;
    if (!quantity) {
      return res.status(400).json({ message: 'quantity is required' });
    }
    const item = await cartService.updateQuantity(req.user!.userId, itemId, quantity);
    return res.json(item);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const removeFromCart = async (req: AuthRequest, res: Response) => {
  try {
    const itemId = parseInt(req.params.itemId as string);
    await cartService.removeFromCart(req.user!.userId, itemId);
    return res.json({ message: 'Item removed from cart' });
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};