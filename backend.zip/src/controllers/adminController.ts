import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
import * as adminService from '../services/admin.service';

export const createProduct = async (req: AuthRequest, res: Response) => {
  try {
    const { name, description, price, stock, subCategoryId } = req.body;
    if (!name || !price || !stock || !subCategoryId) {
      return res.status(400).json({ message: 'name, price, stock and subCategoryId are required' });
    }
    const imagePath = req.file ? `ProductImages/${req.file.filename}` : undefined;
    const product = await adminService.createProduct({
      name,
      description,
      price: parseFloat(price),
      stock: parseInt(stock),
      subCategoryId: parseInt(subCategoryId),
      imagePath,
    });
    return res.status(201).json(product);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const updateProduct = async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id as string);
    const { name, description, price, stock, subCategoryId } = req.body;
    const imagePath = req.file ? `ProductImages/${req.file.filename}` : undefined;
    const product = await adminService.updateProduct(id, {
      name,
      description,
      price: price ? parseFloat(price) : undefined,
      stock: stock ? parseInt(stock) : undefined,
      subCategoryId: subCategoryId ? parseInt(subCategoryId) : undefined,
      imagePath,
    });
    return res.json(product);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const deleteProduct = async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id as string);
    const result = await adminService.deleteProduct(id);
    return res.json(result);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const getAllProducts = async (req: Request, res: Response) => {
  try {
    const products = await adminService.getAllProducts();
    return res.json(products);
  } catch (err: any) {
    return res.status(500).json({ message: err.message });
  }
};

export const getAllCustomers = async (req: Request, res: Response) => {
  try {
    const customers = await adminService.getAllCustomers();
    return res.json(customers);
  } catch (err: any) {
    return res.status(500).json({ message: err.message });
  }
};

export const toggleLockCustomer = async (req: Request, res: Response) => {
  try {
    const customerId = parseInt(req.params.id as string);
    const result = await adminService.toggleLockCustomer(customerId);
    return res.json(result);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const getAllOrders = async (req: Request, res: Response) => {
  try {
    const orders = await adminService.getAllOrders();
    return res.json(orders);
  } catch (err: any) {
    return res.status(500).json({ message: err.message });
  }
};

export const getOrderDetail = async (req: Request, res: Response) => {
  try {
    const orderId = parseInt(req.params.id as string);
    const order = await adminService.getOrderDetail(orderId);
    return res.json(order);
  } catch (err: any) {
    return res.status(404).json({ message: err.message });
  }
};

export function updateProductStatus(arg0: string, updateProductStatus: any) {
    throw new Error('Function not implemented.');
}
