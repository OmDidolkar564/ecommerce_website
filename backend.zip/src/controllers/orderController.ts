import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
import * as orderService from '../services/order.service';

export const placeOrder = async (req: AuthRequest, res: Response) => {
  try {
    const { paymentMethod } = req.body;
    if (!paymentMethod) {
      return res.status(400).json({ message: 'Payment method is required' });
    }

    const validMethods = ['Credit Card', 'Debit Card', 'Cash on Delivery', 'Bank Transfer'];
    if (!validMethods.includes(paymentMethod)) {
      return res.status(400).json({ message: 'Invalid payment method' });
    }

    const order = await orderService.placeOrder(req.user!.userId, paymentMethod);
    return res.status(201).json(order);
  } catch (err: any) {
    return res.status(400).json({ message: err.message });
  }
};

export const getMyOrders = async (req: AuthRequest, res: Response) => {
  try {
    const orders = await orderService.getMyOrders(req.user!.userId);
    return res.json(orders);
  } catch (err: any) {
    return res.status(500).json({ message: err.message });
  }
};

export const getOrderById = async (req: AuthRequest, res: Response) => {
  try {
    const orderId = parseInt(req.params.orderId as string);
    const order = await orderService.getOrderById(req.user!.userId, orderId);
    return res.json(order);
  } catch (err: any) {
    return res.status(404).json({ message: err.message });
  }
};