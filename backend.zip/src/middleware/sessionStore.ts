interface SessionData {
  userId: number;
  role: string;
}

const sessionStore = new Map<string, SessionData>();

export default sessionStore;