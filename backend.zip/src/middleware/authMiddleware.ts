import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import sessionStore from './sessionStore';
import { AppDataSource } from '../../data-source';
import { User } from '../entities/User';

export interface AuthRequest extends Request {
  user?: { userId: number; role: string };
}

export const authenticate = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const token = req.cookies?.token;
    if (!token) {
      return res.status(401).json({ message: 'Not authenticated' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as { userId: number; role: string; sessionId: string };

    // Check session store
    const session = sessionStore.get(decoded.sessionId);
    if (!session) {
      res.clearCookie('token');
      return res.status(401).json({ message: 'Session expired, please log in again' });
    }

    // Check if account is locked
    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { id: decoded.userId } });
    if (!user || user.isLocked) {
      sessionStore.delete(decoded.sessionId);
      res.clearCookie('token');
      return res.status(403).json({ message: 'Account is locked' });
    }

    req.user = { userId: decoded.userId, role: decoded.role };
    next();
  } catch (err) {
    res.clearCookie('token');
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};

export const requireRole = (role: string) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ message: 'Access denied' });
    }
    next();
  };
};