import 'reflect-metadata';
import bcrypt from 'bcrypt'

import * as dotenv from 'dotenv';
dotenv.config();

import { AppDataSource } from '../data-source';
import app from './app';
import { ProductType } from './entities/ProductType';
import { Category } from './entities/Category';
import { SubCategory } from './entities/SubCategory';
import { Product } from './entities/Product';

const seedDatabase = async () => {
  const typeRepo = AppDataSource.getRepository(ProductType);
  const count = await typeRepo.count();
  if (count > 0) {
    console.log('Database already seeded, skipping...');
    return;
  }

  console.log('Seeding database...');

  const { User } = await import('./entities/User');
  const userRepo = AppDataSource.getRepository(User);
  const adminHash = await bcrypt.hash('admin123', 12);
  await userRepo.save(
    userRepo.create({
      name: 'Admin',
      email: 'admin@shop.com',
      passwordHash: adminHash,
      role: 'admin'
    })
  );

  const electronics = typeRepo.create({ name: 'Electronics' });
  const furniture = typeRepo.create({ name: 'Furniture' });
  const stationery = typeRepo.create({ name: 'Stationery' });
  await typeRepo.save([electronics, furniture, stationery]);

  const categoryRepo = AppDataSource.getRepository(Category);
  const peripherals = categoryRepo.create({ name: 'Computer Peripherals', productType: electronics });
  const monitors = categoryRepo.create({ name: 'Monitors & Displays', productType: electronics });
  const tables = categoryRepo.create({ name: 'Tables', productType: furniture });
  const seating = categoryRepo.create({ name: 'Seating', productType: furniture });
  const kids = categoryRepo.create({ name: 'Kids', productType: stationery });
  const office = categoryRepo.create({ name: 'Office Supplies', productType: stationery });
  await categoryRepo.save([peripherals, monitors, tables, seating, kids, office]);

  const subCategoryRepo = AppDataSource.getRepository(SubCategory);
  const keyboards = subCategoryRepo.create({ name: 'Keyboards', category: peripherals });
  const mice = subCategoryRepo.create({ name: 'Mice', category: peripherals });
  const displayScreens = subCategoryRepo.create({ name: 'Screens', category: monitors });
  const diningTables = subCategoryRepo.create({ name: 'Dining Tables', category: tables });
  const deskTables = subCategoryRepo.create({ name: 'Desks', category: tables });
  const sofas = subCategoryRepo.create({ name: 'Sofas', category: seating });
  const textbooks = subCategoryRepo.create({ name: 'Textbooks', category: kids });
  const notebooks = subCategoryRepo.create({ name: 'Notebooks', category: office });
  await subCategoryRepo.save([keyboards, mice, displayScreens, diningTables, deskTables, sofas, textbooks, notebooks]);

  const productRepo = AppDataSource.getRepository(Product);
  const products = productRepo.create([
    {
      name: 'Anker Multimedia Keyboard',
      description: 'A reliable full-size multimedia keyboard perfect for everyday office and home use. Features quiet keys and a comfortable wrist rest.',
      price: 600,
      stock: 50,
      imagePath: 'ProductImages/keyboard1.jpg',
      subCategory: keyboards,
    },
    {
      name: 'Mechanical Gaming Keyboard RGB',
      description: 'Premium mechanical keyboard with RGB backlighting and blue switches. Perfect for gaming and fast typists who want tactile feedback.',
      price: 3000,
      stock: 20,
      imagePath: 'ProductImages/keyboard2.jpg',
      subCategory: keyboards,
    },
    {
      name: 'Wireless Ergonomic Mouse',
      description: 'Ergonomic wireless mouse with 2.4GHz connectivity, adjustable DPI up to 1600, and a battery life of up to 12 months.',
      price: 700,
      stock: 35,
      imagePath: 'ProductImages/mouse.jpg',
      subCategory: mice,
    },
    {
      name: 'Dell 27" Full HD Monitor',
      description: 'Crystal clear 27-inch Full HD IPS display with ultra-thin bezels, 75Hz refresh rate and built-in blue light filter.',
      price: 20000,
      stock: 15,
      imagePath: 'ProductImages/monitor.jpg',
      subCategory: displayScreens,
    },
    {
      name: 'Solid Wood Dining Table',
      description: 'Elegant solid oak dining table that seats 6 people comfortably. Sturdy construction with a natural wood finish.',
      price: 10000,
      stock: 8,
      imagePath: 'ProductImages/table.jpg',
      subCategory: diningTables,
    },
    {
      name: 'Modern Study Desk',
      description: 'Minimalist study desk with a spacious surface, built-in cable management, and a side drawer for storage.',
      price: 15000,
      stock: 12,
      imagePath: 'ProductImages/table.jpg',
      subCategory: deskTables,
    },
    {
      name: 'L-Shape Comfort Sofa',
      description: 'Premium L-shaped sofa with high-density foam cushions and a durable fabric cover. Perfect for living rooms and lounges.',
      price: 25000,
      stock: 5,
      imagePath: 'ProductImages/sofa.jpg',
      subCategory: sofas,
    },
    {
      name: 'Atomic Habits',
      description: 'A book on easy and proven ways to build good habits and break bad ones',
      price: 500,
      stock: 100,
      imagePath: 'ProductImages/book1.jpg',
      subCategory: textbooks,
    },
    {
      name: 'Science for Kids Grade 5',
      description: 'Comprehensive science textbook covering biology, chemistry and physics for grade 5 students with illustrations.',
      price: 350,
      stock: 75,
      imagePath: 'ProductImages/book2.jpg',
      subCategory: textbooks,
    },
    {
      name: 'A5 Spiral Notebook Pack',
      description: 'Pack of 5 high-quality A5 spiral notebooks with 200 pages each. Acid-free paper ideal for writing and sketching.',
      price: 250,
      stock: 200,
      imagePath: 'ProductImages/book2.jpg',
      subCategory: notebooks,
    },
  ]);
  await productRepo.save(products);

  console.log('Seeding complete! 10 products added.');
};

AppDataSource.initialize()
  .then(async () => {
    console.log('Database connected');

    await AppDataSource.runMigrations();
    console.log('Migrations ran successfully');

    await seedDatabase();

    app.listen(3000, () => {
      console.log('Server running on http://localhost:3000');
    });
  })
  .catch((err: Error) => {
    console.log('Cannot connect to DB.', err.message);
    process.exit(1);
  });