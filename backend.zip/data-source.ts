import 'reflect-metadata';
import { DataSource } from 'typeorm';

import { User } from './src/entities/User';
import { ProductType } from './src/entities/ProductType';
import { Category } from './src/entities/Category';
import { SubCategory } from './src/entities/SubCategory';
import { Product } from './src/entities/Product';
import { CartItem } from './src/entities/CartItem';
import { Order } from './src/entities/Order';
import { OrderItem } from './src/entities/OrderItem';
import { ResetCode } from './src/entities/Resetcode';

export const AppDataSource = new DataSource({
  type: 'sqlite',
  database: 'database.sqlite',
  synchronize: false,
  logging: false,
  entities: [User, ProductType, Category, SubCategory, Product, CartItem, Order, OrderItem, ResetCode],
  migrations: ['src/migrations/*.ts'],
});