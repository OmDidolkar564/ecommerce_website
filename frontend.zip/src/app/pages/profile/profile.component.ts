import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  name = '';
  email = '';
  saving = false;
  successMsg = '';
  errorMsg = '';

  constructor(private authService: AuthService) {}

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.name = user.name;
      this.email = user.email;
    }
  }

  save() {
    this.successMsg = '';
    this.errorMsg = '';

    if (!this.name || !this.email) {
      this.errorMsg = 'Name and email are required';
      return;
    }

    this.saving = true;
    this.authService.updateProfile(this.name, this.email).subscribe({
      next: () => {
        this.successMsg = 'Profile updated successfully!';
        this.saving = false;
      },
      error: (err) => {
        this.errorMsg = err.error?.message || 'Failed to update profile';
        this.saving = false;
      }
    });
  }
}