import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product/product.service';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: any[] = [];
  types: any[] = [];
  categories: any[] = [];
  subCategories: any[] = [];

  search = '';
  selectedTypeId: any = '';
  selectedCategoryId: any = '';
  selectedSubCategoryId: any = '';
  minPrice: any = '';
  maxPrice: any = '';
  inStock = false;

  currentPage = 1;
  totalPages = 1;
  total = 0;
  loading = false;

  constructor(private productService: ProductService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.productService.getTypes().subscribe(types => this.types = types);
    this.route.queryParams.subscribe(params => {
      this.search = params['search'] || '';
      this.selectedTypeId = params['typeId'] || '';
      this.loadProducts();
    });
  }

  loadProducts() {
    this.loading = true;
    const filters = {
      page: this.currentPage, limit: 12, search: this.search,
      typeId: this.selectedTypeId, categoryId: this.selectedCategoryId,
      subCategoryId: this.selectedSubCategoryId, minPrice: this.minPrice,
      maxPrice: this.maxPrice, inStock: this.inStock || undefined
    };

    this.productService.getProducts(filters).subscribe({
      next: (res) => {
        this.products = res.products;
        this.totalPages = res.totalPages;
        this.total = res.total;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  onTypeChange() {
    this.selectedCategoryId = ''; this.selectedSubCategoryId = '';
    this.categories = []; this.subCategories = [];
    if (this.selectedTypeId) {
      this.productService.getCategoriesByType(this.selectedTypeId).subscribe(cats => this.categories = cats);
    }
    this.onFilterChange();
  }

  onCategoryChange() {
    this.selectedSubCategoryId = ''; this.subCategories = [];
    if (this.selectedCategoryId) {
      this.productService.getSubCategoriesByCategory(this.selectedCategoryId).subscribe(subs => this.subCategories = subs);
    }
    this.onFilterChange();
  }

  onFilterChange() { this.currentPage = 1; this.loadProducts(); }
  onSearch() { this.onFilterChange(); }
  goToPage(p: number) { if (p >= 1 && p <= this.totalPages) { this.currentPage = p; this.loadProducts(); } }
  getPages() { return Array.from({ length: this.totalPages }, (_, i) => i + 1); }
  getImageUrl(path: string) { return this.productService.getImageUrl(path); }
}