import { Component, OnInit, ChangeDetectorRef } from '@angular/core'
import { ActivatedRoute, RouterLink } from '@angular/router'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { ProductService } from '../../services/product/product.service'

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: any[] = []
  types: any[] = []
  categories: any[] = []
  subCategories: any[] = []

  search = ''
  selectedTypeId: any = ''
  selectedCategoryId: any = ''
  selectedSubCategoryId: any = ''
  minPrice: any = ''
  maxPrice: any = ''
  inStock = false

  currentPage = 1
  totalPages = 1
  total = 0
  limit = 12
  loading = false

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {

    this.productService.getTypes().subscribe({
      next: data => this.types = data || [],
      error: () => this.types = []
    })

    this.route.queryParams.subscribe(params => {

      this.search = params['search'] || ''
      this.selectedTypeId = params['typeId'] || ''

      this.selectedCategoryId = ''
      this.selectedSubCategoryId = ''

      this.categories = []
      this.subCategories = []

      this.currentPage = 1

      if (this.selectedTypeId) {
        this.productService.getCategoriesByType(this.selectedTypeId).subscribe({
          next: data => this.categories = data || [],
          error: () => this.categories = []
        })
      }

      this.loadProducts()
    })
  }

  loadProducts() {

    this.loading = true

    const filters: any = {
      page: this.currentPage,
      limit: this.limit
    }

    if (this.search) filters.search = this.search
    if (this.selectedTypeId) filters.typeId = this.selectedTypeId
    if (this.selectedCategoryId) filters.categoryId = this.selectedCategoryId
    if (this.selectedSubCategoryId) filters.subCategoryId = this.selectedSubCategoryId
    if (this.minPrice) filters.minPrice = this.minPrice
    if (this.maxPrice) filters.maxPrice = this.maxPrice
    if (this.inStock) filters.inStock = true

    this.productService.getProducts(filters).subscribe({
      next: (res: any) => {

        if (Array.isArray(res)) {
          this.products = res
          this.total = res.length
          this.totalPages = 1
        } else {
          this.products = res?.products || []
          this.total = res?.total || 0
          this.totalPages = res?.totalPages || 1
        }

        this.loading = false
        this.cdr.detectChanges()
      },
      error: () => {
        this.products = []
        this.total = 0
        this.totalPages = 1
        this.loading = false
        this.cdr.detectChanges()
      }
    })
  }

  onTypeChange() {

    this.selectedCategoryId = ''
    this.selectedSubCategoryId = ''
    this.categories = []
    this.subCategories = []

    if (!this.selectedTypeId) {
      this.onFilterChange()
      return
    }

    this.productService.getCategoriesByType(this.selectedTypeId).subscribe({
      next: data => this.categories = data || [],
      error: () => this.categories = []
    })

    this.onFilterChange()
  }

  onCategoryChange() {

    this.selectedSubCategoryId = ''
    this.subCategories = []

    if (!this.selectedCategoryId) {
      this.onFilterChange()
      return
    }

    this.productService.getSubCategoriesByCategory(this.selectedCategoryId).subscribe({
      next: data => this.subCategories = data || [],
      error: () => this.subCategories = []
    })

    this.onFilterChange()
  }

  onFilterChange() {
    this.currentPage = 1
    this.loadProducts()
  }

  onSearch() {
    this.currentPage = 1
    this.loadProducts()
  }

  goToPage(page: number) {
    if (page < 1 || page > this.totalPages) return
    this.currentPage = page
    this.loadProducts()
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1)
  }

  getImageUrl(path: string) {
    return this.productService.getImageUrl(path)
  }

  setDefaultImage(event: Event) {
    const img = event.target as HTMLImageElement
    img.src = '/assets/default.png'
  }

  resetFilters() {

    this.search = ''
    this.selectedTypeId = ''
    this.selectedCategoryId = ''
    this.selectedSubCategoryId = ''
    this.minPrice = ''
    this.maxPrice = ''
    this.inStock = false

    this.categories = []
    this.subCategories = []

    this.currentPage = 1

    this.loadProducts()
  }
}