import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ProductsComponent } from './products.component';

@NgModule({
  imports: [
    ProductsComponent,
    RouterModule.forChild([{ path: '', component: ProductsComponent }])
  ]
})
export class ProductsModule {}