import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { OrderService } from '../../services/order/order.service';

@Component({
  selector: 'app-order-confirmation',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './order-confirmation.html',
  styleUrl: './order-confirmation.css'
})
export class OrderConfirmationComponent implements OnInit {
  order: any = null;
  loading = true;

  constructor(private route: ActivatedRoute, private orderService: OrderService) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.orderService.getOrderById(parseInt(id)).subscribe({
        next: (order) => { this.order = order; this.loading = false; },
        error: () => { this.loading = false; }
      });
    }
  }

  getTotal(): number {
    if (!this.order?.orderItems) return 0;
    return this.order.orderItems.reduce((sum: number, item: any) =>
      sum + item.priceAtPurchase * item.quantity, 0);
  }
}