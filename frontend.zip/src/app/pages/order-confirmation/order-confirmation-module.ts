import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { OrderConfirmationComponent } from './order-confirmation.component';

@NgModule({
  imports: [RouterModule.forChild([{ path: '', component: OrderConfirmationComponent }])]
})
export class OrderConfirmationModule { }