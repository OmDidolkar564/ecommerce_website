import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../services/cart/cart.service';
import { ProductService } from '../../services/product/product.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  loading = true;

  constructor(
    private cartService: CartService,
    private productService: ProductService,
    private router: Router
  ) {}

  ngOnInit() {
    this.cartService.getCart().subscribe({
      next: (items) => { this.cartItems = items; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getImageUrl(path: string) {
    return this.productService.getImageUrl(path);
  }

  updateQuantity(itemId: number, quantity: number) {
    const qty = Number(quantity); // ngModelChange passes a string, convert it
    this.cartService.updateQuantity(itemId, qty).subscribe({
      next: () => {
        const item = this.cartItems.find(i => i.id === itemId);
        if (item) item.quantity = qty;
      }
    });
  }

  removeItem(itemId: number) {
    this.cartService.removeFromCart(itemId).subscribe({
      next: () => {
        this.cartItems = this.cartItems.filter(i => i.id !== itemId);
        this.cartService.clearCartCount();
        // Recount from remaining items
        this.cartService['cartCountSubject']?.next(
          this.cartItems.reduce((s, i) => s + i.quantity, 0)
        );
      }
    });
  }

  getTotal(): number {
    return this.cartItems.reduce((s, i) => s + i.product.price * i.quantity, 0);
  }
}