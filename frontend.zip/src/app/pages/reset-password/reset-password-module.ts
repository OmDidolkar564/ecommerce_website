import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ResetPasswordComponent } from './reset-password.component';

@NgModule({
  imports: [
    ResetPasswordComponent,
    RouterModule.forChild([{ path: '', component: ResetPasswordComponent }])
  ]
})
export class ResetPasswordModule {}