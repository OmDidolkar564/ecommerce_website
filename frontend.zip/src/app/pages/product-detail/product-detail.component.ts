import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product/product.service';
import { CartService } from '../../services/cart/cart.service';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  product: any = null;
  relatedProducts: any[] = [];
  quantity = 1;
  loading = true;
  isLoggedIn = false;
  addedToCart = false;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private authService: AuthService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.isLoggedIn = this.authService.isLoggedIn();
    this.route.params.subscribe(params => {
      const id = params['id'];
      this.loadProduct(id);
    });
  }

  loadProduct(id: number) {
    this.loading = true;
    this.productService.getProductById(id).subscribe({
      next: (product) => {
        this.product = product;
        this.quantity = 1;
        this.addedToCart = false;
        this.loadRelatedProducts(product.subCategoryId);
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  loadRelatedProducts(subCategoryId: number) {
    this.productService.getProducts({ subCategoryId, limit: 4 }).subscribe({
      next: (res: any) => {
        this.relatedProducts = res.products.filter((p: any) => p.id !== this.product.id).slice(0, 4);
      }
    });
  }

  increaseQty() {
    if (this.quantity < this.product.stock) this.quantity++;
  }

  decreaseQty() {
    if (this.quantity > 1) this.quantity--;
  }

  addToCart() {
    if (!this.isLoggedIn) {
      alert('Please log in to add items to cart');
      return;
    }
    this.cartService.addToCart(this.product.id, this.quantity).subscribe({
      next: () => {
        this.addedToCart = true;
        setTimeout(() => this.addedToCart = false, 2000);
      },
      error: (err) => {
        const msg = err?.error?.message || 'Could not add to cart. Please try again.';
        alert('Error: ' + msg);
      }
    });
  }

  shareProduct() {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({
        title: this.product.name,
        text: this.product.description,
        url: url
      });
    } else {
      navigator.clipboard.writeText(url).then(() => {
        alert('Product link copied to clipboard!');
      });
    }
  }

  getImageUrl(imagePath: string) {
    return this.productService.getImageUrl(imagePath);
  }

  getTaxonomyPath(): string {
    if (!this.product?.subCategory) return '';
    const type = this.product.subCategory.category?.productType?.name || '';
    const category = this.product.subCategory.category?.name || '';
    const subCategory = this.product.subCategory.name || '';
    return `${type} > ${category} > ${subCategory}`;
  }
}