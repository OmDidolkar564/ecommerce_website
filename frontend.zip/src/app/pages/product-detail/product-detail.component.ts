import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product/product.service';
import { CartService } from '../../services/cart/cart.service';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})
export class ProductDetailComponent implements OnInit {
  product: any = null;
  loading = true;
  quantity = 1;
  addedToCart = false;
  errorMessage = '';
  isLoggedIn = false;

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private cartService: CartService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.isLoggedIn = this.authService.isLoggedIn();
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.productService.getProductById(parseInt(id)).subscribe({
        next: (product) => {
          this.product = product;
          this.loading = false;
        },
        error: () => { this.loading = false; }
      });
    }
  }

  getImageUrl(imagePath: string) {
    return this.productService.getImageUrl(imagePath);
  }

  addToCart() {
    if (!this.isLoggedIn) return;
    this.errorMessage = '';
    this.cartService.addToCart(this.product.id, this.quantity).subscribe({
      next: () => {
        this.addedToCart = true;
        setTimeout(() => this.addedToCart = false, 3000);
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Could not add to cart';
      }
    });
  }

  shareProduct() {
    const url = window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        alert('Product link copied to clipboard!');
      });
    } else {
      prompt('Copy this link:', url);
    }
  }
}