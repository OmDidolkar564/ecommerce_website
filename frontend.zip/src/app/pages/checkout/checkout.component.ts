import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../services/cart/cart.service';
import { OrderService } from '../../services/order/order.service';
import { AuthService } from '../../services/auth/auth.service';
import { ProductService } from '../../services/product/product.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  cartItems: any[] = [];
  user: any = null;
  loading = true;
  placing = false;
  error = '';
  selectedPayment = 'Cash on Delivery';
  paymentMethods = ['Cash on Delivery', 'Credit Card', 'Debit Card', 'UPI', 'Net Banking'];

  get subtotal() {
    return this.cartItems.reduce((s, i) => s + i.product.price * i.quantity, 0);
  }

  get total() {
    return this.subtotal >= 999 ? this.subtotal : this.subtotal + 99;
  }

  constructor(
    private cartService: CartService,
    private orderService: OrderService,
    private authService: AuthService,
    private productService: ProductService,
    private router: Router
  ) {}

  ngOnInit() {
    this.user = this.authService.getCurrentUser();
    this.cartService.getCart().subscribe({
      next: (items) => { this.cartItems = items; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getImageUrl(path: string) {
    return this.productService.getImageUrl(path);
  }

  placeOrder() {
    this.placing = true;
    this.error = '';
    this.orderService.placeOrder(this.selectedPayment).subscribe({
      next: (order) => {
        this.cartService.clearCartCount();
        this.router.navigate(['/order-confirmation', order.id]);
      },
      error: (err) => {
        this.error = err.error?.message || 'Failed to place order. Please try again.';
        this.placing = false;
      }
    });
  }
}