import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';
import { OrderService } from '../../services/order/order.service';
import { ProductService } from '../../services/product/product.service';

@Component({
  selector: 'app-order-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, DatePipe],
  templateUrl: './order-detail.component.html',
  styleUrls: ['./order-detail.component.css']
})
export class OrderDetailComponent implements OnInit {
  order: any = null;
  loading = true;

  get subtotal() {
    return this.order?.orderItems?.reduce(
      (s: number, i: any) => s + i.priceAtPurchase * i.quantity, 0
    ) || 0;
  }

  constructor(
    private route: ActivatedRoute,
    private orderService: OrderService,
    private productService: ProductService
  ) {}

  ngOnInit() {
    const id = parseInt(this.route.snapshot.paramMap.get('id') || '0');
    this.orderService.getOrderById(id).subscribe({
      next: (order) => { this.order = order; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getImageUrl(path: string) {
    return this.productService.getImageUrl(path);
  }
}