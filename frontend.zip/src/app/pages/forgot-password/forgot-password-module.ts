import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ForgotPasswordComponent } from './forget-password.component';

@NgModule({
  imports: [
    ForgotPasswordComponent,
    RouterModule.forChild([{ path: '', component: ForgotPasswordComponent }])
  ]
})
export class ForgotPasswordModule {}