import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {
  email = '';
  resetCode = '';
  codeSent = false;
  loading = false;
  errorMessage = '';

  constructor(private authService: AuthService, private router: Router) { }

  requestCode() {
    if (!this.email) {
      this.errorMessage = 'Email is required';
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    this.authService.forgotPassword(this.email).subscribe({
      next: (res) => {
        this.resetCode = res.code || '';
        this.codeSent = true;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Failed to send reset code';
        this.loading = false;
      }
    });
  }

  goToReset() {
    this.router.navigate(['/reset-password'], {
      state: { email: this.email, code: this.resetCode }
    });
  }
}