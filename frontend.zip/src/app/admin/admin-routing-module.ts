import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductListComponent } from './pages/product-list/product-list.component';
import { ProductForm } from './pages/product-form/product-form.component';
import { CustomerList } from './pages/customer-list/customer-list.component';
import { OrderList } from './pages/order-list/order-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'products', pathMatch: 'full' },
  { path: 'products', component: ProductListComponent },
  { path: 'products/add', component: ProductForm },
  { path: 'products/edit/:id', component: ProductForm },
  { path: 'customers', component: CustomerList },
  { path: 'orders', component: OrderList },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }