import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AdminService } from '../../../services/admin/admin.service';
import { ProductService } from '../../../services/product/product.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products: any[] = [];
  allProducts: any[] = [];

  loading = true;
  message = '';
  searchQuery = '';

  constructor(
    private adminService: AdminService,
    private productService: ProductService,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.loading = true;

    this.adminService.getProducts().subscribe({
      next: (products) => {
        this.products = products || [];
        this.allProducts = [...this.products];

        this.loading = false;
        this.cd.detectChanges();
      },
      error: () => {
        this.products = [];
        this.allProducts = [];

        this.loading = false;
        this.cd.detectChanges();
      }
    });
  }

  getImageUrl(imagePath: string) {
    return this.productService.getImageUrl(imagePath);
  }

  deleteProduct(id: number) {
    if (!confirm('Are you sure you want to delete this product?')) return;

    this.adminService.deleteProduct(id).subscribe({
      next: () => {
        this.message = 'Product deleted successfully';
        this.loadProducts();
      },
      error: (err) => {
        this.message = err.error?.message || 'Delete failed';
        this.cd.detectChanges();
      }
    });
  }

  search(): void {

    const term = this.searchQuery.trim().toLowerCase();

    if (!term) {
      this.products = [...this.allProducts];
      return;
    }

    this.products = this.allProducts.filter(product =>
      product.name?.toLowerCase().includes(term) ||
      product.subCategory?.name?.toLowerCase().includes(term) ||
      product.subCategory?.category?.name?.toLowerCase().includes(term) ||
      product.subCategory?.category?.productType?.name?.toLowerCase().includes(term)
    );
  }

}