import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin/admin.service';
import { ProductService } from '../../../services/product/product.service';

@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css',
})
export class ProductForm implements OnInit {
  isEdit = false;
  productId: number | null = null;

  name = '';
  description = '';
  price: any = '';
  stock: any = '';
  subCategoryId: any = '';
  selectedFile: File | null = null;
  currentImage = '';

  types: any[] = [];
  categories: any[] = [];
  subCategories: any[] = [];
  selectedTypeId: any = '';
  selectedCategoryId: any = '';

  loading = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService,
    private productService: ProductService
  ) { }

  ngOnInit() {
    this.productService.getTypes().subscribe(types => { this.types = types; });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.productId = parseInt(id);
      this.productService.getProductById(this.productId).subscribe({
        next: (product) => {
          this.name = product.name;
          this.description = product.description || '';
          this.price = product.price;
          this.stock = product.stock;
          this.currentImage = product.imagePath || '';
          this.selectedTypeId = product.subCategory?.category?.productType?.id || '';
          this.selectedCategoryId = product.subCategory?.category?.id || '';
          this.subCategoryId = product.subCategory?.id || '';

          if (this.selectedTypeId) {
            this.productService.getCategoriesByType(this.selectedTypeId).subscribe(cats => {
              this.categories = cats;
              if (this.selectedCategoryId) {
                this.productService.getSubCategoriesByCategory(this.selectedCategoryId).subscribe(subs => {
                  this.subCategories = subs;
                });
              }
            });
          }
        },
        error: () => { this.errorMessage = 'Could not load product'; }
      });
    }
  }

  onTypeChange() {
    this.categories = [];
    this.subCategories = [];
    this.selectedCategoryId = '';
    this.subCategoryId = '';
    if (this.selectedTypeId) {
      this.productService.getCategoriesByType(this.selectedTypeId).subscribe(cats => {
        this.categories = cats;
      });
    }
  }

  onCategoryChange() {
    this.subCategories = [];
    this.subCategoryId = '';
    if (this.selectedCategoryId) {
      this.productService.getSubCategoriesByCategory(this.selectedCategoryId).subscribe(subs => {
        this.subCategories = subs;
      });
    }
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) this.selectedFile = file;
  }

  getImageUrl(path: string) {
    return this.productService.getImageUrl(path);
  }

  onSubmit() {
    this.errorMessage = '';
    this.successMessage = '';

    if (!this.name || !this.price || this.stock === '' || !this.subCategoryId) {
      this.errorMessage = 'Name, price, stock and sub-category are required';
      return;
    }

    const formData = new FormData();
    formData.append('name', this.name.trim());
    formData.append('description', this.description.trim());
    formData.append('price', this.price.toString());
    formData.append('stock', this.stock.toString());
    formData.append('subCategoryId', this.subCategoryId.toString());
    if (this.selectedFile) formData.append('image', this.selectedFile);

    this.loading = true;

    if (this.isEdit && this.productId) {
      this.adminService.updateProduct(this.productId, formData).subscribe({
        next: () => {
          this.successMessage = 'Product updated successfully';
          this.loading = false;
          setTimeout(() => this.router.navigate(['/admin/products']), 1500);
        },
        error: (err) => {
          this.errorMessage = err.error?.message || 'Update failed';
          this.loading = false;
        }
      });
    } else {
      this.adminService.createProduct(formData).subscribe({
        next: () => {
          this.successMessage = 'Product created successfully';
          this.loading = false;
          setTimeout(() => this.router.navigate(['/admin/products']), 1500);
        },
        error: (err) => {
          this.errorMessage = err.error?.message || 'Create failed';
          this.loading = false;
        }
      });
    }
  }
}