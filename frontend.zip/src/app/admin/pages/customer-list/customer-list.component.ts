import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../services/admin/admin.service';

@Component({
  selector: 'app-customer-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './customer-list.component.html',
  styleUrl: './customer-list.component.css',
})
export class CustomerList implements OnInit {
  customers: any[] = [];
  loading = true;
  message = '';

  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.loadCustomers();
  }

  loadCustomers() {
    this.adminService.getCustomers().subscribe({
      next: (customers) => { this.customers = customers; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  toggleLock(customerId: number, isLocked: boolean) {
    const action = isLocked ? 'unlock' : 'lock';
    if (!confirm(`Are you sure you want to ${action} this account?`)) return;
    this.adminService.toggleLock(customerId).subscribe({
      next: (res) => { this.message = res.message; this.loadCustomers(); },
      error: (err) => { this.message = err.error?.message || 'Action failed'; }
    });
  }
}