import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../services/admin/admin.service';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.css',
})
export class OrderList implements OnInit {
  orders: any[] = [];
  loading = true;
  expandedOrderId: number | null = null;

  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.adminService.getOrders().subscribe({
      next: (orders) => { this.orders = orders; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  toggleExpand(orderId: number) {
    this.expandedOrderId = this.expandedOrderId === orderId ? null : orderId;
  }

  getTotal(order: any): number {
    return order.orderItems?.reduce((sum: number, item: any) =>
      sum + item.priceAtPurchase * item.quantity, 0) || 0;
  }
}