import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getProducts(filters: any = {}): Observable<any> {
    let params = new HttpParams();
    if (filters.search) params = params.set('search', filters.search);
    if (filters.typeId) params = params.set('typeId', filters.typeId);
    if (filters.categoryId) params = params.set('categoryId', filters.categoryId);
    if (filters.subCategoryId) params = params.set('subCategoryId', filters.subCategoryId);
    if (filters.minPrice) params = params.set('minPrice', filters.minPrice);
    if (filters.maxPrice) params = params.set('maxPrice', filters.maxPrice);
    if (filters.inStock) params = params.set('inStock', filters.inStock);
    if (filters.page) params = params.set('page', filters.page);
    if (filters.limit) params = params.set('limit', filters.limit);
    return this.http.get(`${this.apiUrl}/products`, { params });
  }

  getProductById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/products/${id}`);
  }

  getTypes(): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy/types`);
  }

  getCategoriesByType(typeId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy/categories/${typeId}`);
  }

  getSubCategoriesByCategory(categoryId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy/subcategories/${categoryId}`);
  }

  getImageUrl(imagePath: string | null): string {
    if (!imagePath) return 'http://localhost:3000/images/default.png';
    return `http://localhost:3000/images/${imagePath.replace('ProductImages/', '')}`;
  }
}