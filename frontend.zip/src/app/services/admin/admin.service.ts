import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
const API_URL = '/api';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = API_URL;

  constructor(private http: HttpClient) {}

  getProducts(): Observable<any> {
    return this.http.get(`${this.apiUrl}/admin/products`, { withCredentials: true });
  }

  createProduct(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/admin/products`, formData, { withCredentials: true });
  }

  updateProduct(id: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/admin/products/${id}`, formData, { withCredentials: true });
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/admin/products/${id}`, { withCredentials: true });
  }

  getCustomers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/admin/customers`, { withCredentials: true });
  }

  toggleLock(customerId: number): Observable<any> {
    return this.http.patch(`${this.apiUrl}/admin/customers/${customerId}/lock`, {}, { withCredentials: true });
  }

  getOrders(): Observable<any> {
    return this.http.get(`${this.apiUrl}/admin/orders`, { withCredentials: true });
  }

  getOrderDetail(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/admin/orders/${id}`, { withCredentials: true });
  }
}