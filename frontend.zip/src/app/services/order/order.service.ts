import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
const API_URL = '/api';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = API_URL;

  constructor(private http: HttpClient) { }

  placeOrder(paymentMethod: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/orders`, { paymentMethod }, { withCredentials: true });
  }

  getMyOrders(): Observable<any> {
    return this.http.get(`${this.apiUrl}/orders`, { withCredentials: true });
  }

  getOrderById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/orders/${id}`, { withCredentials: true });
  }
}