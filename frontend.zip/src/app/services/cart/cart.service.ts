import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
const API_URL = '/api';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private apiUrl = API_URL;
  private cartCountSubject = new BehaviorSubject<number>(0);
  cartCount$ = this.cartCountSubject.asObservable();

  constructor(private http: HttpClient) { }

  getCart(): Observable<any> {
    return this.http.get(`${this.apiUrl}/cart`, { withCredentials: true }).pipe(
      tap((items: any) => {
        this.cartCountSubject.next(items.length);
      })
    );
  }

  addToCart(productId: number, quantity: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/cart`, { productId, quantity }, { withCredentials: true }).pipe(
      tap(() => this.cartCountSubject.next(this.cartCountSubject.value + 1))
    );
  }

  updateQuantity(itemId: number, quantity: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/cart/${itemId}`, { quantity }, { withCredentials: true });
  }

  removeFromCart(itemId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/cart/${itemId}`, { withCredentials: true }).pipe(
      tap(() => this.cartCountSubject.next(Math.max(0, this.cartCountSubject.value - 1)))
    );
  }

  clearCartCount(): void {
    this.cartCountSubject.next(0);
  }
}