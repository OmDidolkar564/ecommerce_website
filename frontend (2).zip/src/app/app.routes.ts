import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth-guard';
import { AdminGuard } from './guards/admin-guard';

export const routes: Routes = [
  { path: '', loadChildren: () => import('./pages/home/home-module').then(m => m.HomeModule) },
  { path: 'products', loadChildren: () => import('./pages/products/products-module').then(m => m.ProductsModule) },
  { path: 'products/:id', loadChildren: () => import('./pages/product-detail/product-detail-module').then(m => m.ProductDetailModule) },
  { path: 'login', loadChildren: () => import('./pages/login/login-module').then(m => m.LoginModule) },
  { path: 'register', loadChildren: () => import('./pages/register/register-module').then(m => m.RegisterModule) },
  { path: 'forgot-password', loadChildren: () => import('./pages/forgot-password/forgot-password-module').then(m => m.ForgotPasswordModule) },
  { path: 'reset-password', loadChildren: () => import('./pages/reset-password/reset-password-module').then(m => m.ResetPasswordModule) },
  { path: 'cart', loadChildren: () => import('./pages/cart/cart-module').then(m => m.CartModule), canActivate: [AuthGuard] },
  { path: 'checkout', loadChildren: () => import('./pages/checkout/checkout-module').then(m => m.CheckoutModule), canActivate: [AuthGuard] },
  { path: 'order-confirmation/:id', loadChildren: () => import('./pages/order-confirmation/order-confirmation-module').then(m => m.OrderConfirmationModule), canActivate: [AuthGuard] },
  { path: 'orders', loadChildren: () => import('./pages/order-history/order-history-module').then(m => m.OrderHistoryModule), canActivate: [AuthGuard] },
  { path: 'orders/:id', loadChildren: () => import('./pages/order-detail/order-detail-module').then(m => m.OrderDetailModule), canActivate: [AuthGuard] },
  { path: 'profile', loadChildren: () => import('./pages/profile/profile-module').then(m => m.ProfileModule), canActivate: [AuthGuard] },
  { path: 'change-password', loadChildren: () => import('./pages/change-password/change-password-module').then(m => m.ChangePasswordModule), canActivate: [AuthGuard] },
  { path: 'admin', loadChildren: () => import('./admin/admin-module').then(m => m.AdminModule), canActivate: [AuthGuard, AdminGuard] },
  { path: '**', redirectTo: '' }
];