import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
const API_URL = '/api';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = API_URL;

  constructor(private http: HttpClient) { }

  getProducts(filters: any = {}): Observable<any> {
    let params = new HttpParams();
    if (filters.search) params = params.set('search', filters.search);
    if (filters.typeId) params = params.set('typeId', filters.typeId);
    if (filters.categoryId) params = params.set('categoryId', filters.categoryId);
    if (filters.subCategoryId) params = params.set('subCategoryId', filters.subCategoryId);
    if (filters.minPrice) params = params.set('minPrice', filters.minPrice);
    if (filters.maxPrice) params = params.set('maxPrice', filters.maxPrice);
    if (filters.inStock) params = params.set('inStock', filters.inStock);
    if (filters.page) params = params.set('page', filters.page);
    if (filters.limit) params = params.set('limit', filters.limit);
    return this.http.get(`${this.apiUrl}/products`, { params });
  }

  getProductById(id: number): Observable<any> {
    console.log(`Fetching product from: ${this.apiUrl}/products/${id}`);
    return this.http.get(`${this.apiUrl}/products/${id}`);
  }

  getTypes(): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy/types`);
  }

  getCategoriesByType(typeId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy/categories/${typeId}`);
  }

  getSubCategoriesByCategory(categoryId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy/subcategories/${categoryId}`);
  }

  getImageUrl(imagePath: string | null): string {
    const base = this.apiUrl.replace('/api', '');
    if (!imagePath) return `${base}/images/default.png`;
    const cleanPath = imagePath.replace('ProductImages/', '');
    return `${base}/images/${cleanPath}`;
  }
}