import { NgModule } from '@angular/core';
import { OrderDetailComponent } from './order-detail.component';
import { OrderDetailRoutingModule } from './order-detail-routing-module';

@NgModule({
  imports: [OrderDetailComponent, OrderDetailRoutingModule]
})
export class OrderDetailModule { }