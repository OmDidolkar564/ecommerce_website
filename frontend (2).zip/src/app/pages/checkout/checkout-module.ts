import { NgModule } from '@angular/core';
import { CheckoutComponent } from './checkout.component';
import { CheckoutRoutingModule } from './checkout-routing-module';

@NgModule({
  imports: [CheckoutComponent, CheckoutRoutingModule]
})
export class CheckoutModule { }