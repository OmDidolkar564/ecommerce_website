import { NgModule } from '@angular/core';
import { ChangePasswordComponent } from './change-password.component';
import { ChangePasswordRoutingModule } from './change-password-routing-module';

@NgModule({
  imports: [ChangePasswordComponent, ChangePasswordRoutingModule]
})
export class ChangePasswordModule { }