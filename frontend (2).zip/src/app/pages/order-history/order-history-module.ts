import { NgModule } from '@angular/core';
import { OrderHistoryComponent } from './order-history.component';
import { OrderHistoryRoutingModule } from './order-history-routing-module';

@NgModule({
  imports: [OrderHistoryComponent, OrderHistoryRoutingModule]
})
export class OrderHistoryModule { }