import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ProductDetailComponent } from './product-detail.component';

@NgModule({
  imports: [
    ProductDetailComponent,
    RouterModule.forChild([{ path: '', component: ProductDetailComponent }])
  ]
})
export class ProductDetailModule { }