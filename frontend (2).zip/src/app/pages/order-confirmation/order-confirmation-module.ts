import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { OrderConfirmationComponent } from './order-confirmation.component';

@NgModule({
  imports: [
    OrderConfirmationComponent,
    RouterModule.forChild([{ path: '', component: OrderConfirmationComponent }])
  ]
})
export class OrderConfirmationModule { }