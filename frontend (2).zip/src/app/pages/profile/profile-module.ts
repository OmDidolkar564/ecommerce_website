import { NgModule } from '@angular/core';
import { ProfileComponent } from './profile.component';
import { ProfileRoutingModule } from './profile-routing-module';

@NgModule({
  imports: [ProfileComponent, ProfileRoutingModule]
})
export class ProfileModule { }