import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product/product.service';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: any[] = [];
  types: any[] = [];
  categories: any[] = [];
  subCategories: any[] = [];

  search = '';
  selectedTypeId: any = '';
  selectedCategoryId: any = '';
  selectedSubCategoryId: any = '';
  minPrice: any = '';
  maxPrice: any = '';
  inStock = false;

  currentPage = 1;
  totalPages = 1;
  total = 0;
  limit = 12;
  loading = false;

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.productService.getTypes().subscribe(types => this.types = types);

    this.route.queryParams.subscribe(params => {
      this.search = params['search'] || '';
      this.selectedTypeId = params['typeId'] || '';

      // If arriving with a typeId, pre-load its categories
      if (this.selectedTypeId) {
        this.productService.getCategoriesByType(this.selectedTypeId).subscribe(cats => {
          this.categories = cats;
        });
      }

      this.currentPage = 1;
      this.loadProducts();
    });
  }

  loadProducts() {
    this.loading = true;
    const filters: any = {
      page: this.currentPage,
      limit: this.limit,
    };

    if (this.search)              filters.search        = this.search;
    if (this.selectedTypeId)      filters.typeId        = this.selectedTypeId;
    if (this.selectedCategoryId)  filters.categoryId    = this.selectedCategoryId;
    if (this.selectedSubCategoryId) filters.subCategoryId = this.selectedSubCategoryId;
    if (this.minPrice)            filters.minPrice      = this.minPrice;
    if (this.maxPrice)            filters.maxPrice      = this.maxPrice;
    if (this.inStock)             filters.inStock       = true;

    this.productService.getProducts(filters).subscribe({
      next: (res) => {
        this.products   = res.products;
        this.totalPages = res.totalPages;
        this.total      = res.total;
        this.loading    = false;
      },
      error: () => { this.loading = false; }
    });
  }

  onTypeChange() {
    this.selectedCategoryId    = '';
    this.selectedSubCategoryId = '';
    this.categories            = [];
    this.subCategories         = [];

    if (this.selectedTypeId) {
      this.productService.getCategoriesByType(this.selectedTypeId).subscribe(cats => {
        this.categories = cats;
      });
    }

    this.onFilterChange();
  }

  onCategoryChange() {
    this.selectedSubCategoryId = '';
    this.subCategories         = [];

    if (this.selectedCategoryId) {
      this.productService.getSubCategoriesByCategory(this.selectedCategoryId).subscribe(subs => {
        this.subCategories = subs;
      });
    }

    this.onFilterChange();
  }

  onFilterChange() {
    this.currentPage = 1;
    this.loadProducts();
  }

  onSearch() {
    this.currentPage = 1;
    this.loadProducts();
  }

  goToPage(page: number) {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
    this.loadProducts();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  getImageUrl(path: string) {
    return this.productService.getImageUrl(path);
  }
}