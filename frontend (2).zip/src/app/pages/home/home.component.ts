import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product/product.service';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  featuredProducts: any[] = [];
  types: any[] = [];
  loading = true;
  isLoggedIn = false;
  currentSlide = 0;
  totalSlides = 4;
  sliderInterval: any;

  constructor(
    private productService: ProductService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.isLoggedIn = this.authService.isLoggedIn();
    this.productService.getProducts({ limit: 8 }).subscribe({
      next: (res) => { this.featuredProducts = res.products; this.loading = false; },
      error: () => { this.loading = false; }
    });
    this.productService.getTypes().subscribe({
      next: (types) => { this.types = types; }
    });
    this.startSlider();
  }

  ngOnDestroy() {
    clearInterval(this.sliderInterval);
  }

  startSlider() {
    this.sliderInterval = setInterval(() => {
      this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
    }, 5000);
  }

  nextSlide() {
    clearInterval(this.sliderInterval);
    this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
    this.startSlider();
  }

  prevSlide() {
    clearInterval(this.sliderInterval);
    this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
    this.startSlider();
  }

  goToSlide(i: number) {
    clearInterval(this.sliderInterval);
    this.currentSlide = i;
    this.startSlider();
  }

  getImageUrl(imagePath: string) {
    return this.productService.getImageUrl(imagePath);
  }

  browseByType(typeId: number) {
    if (typeId === 0) {
      this.router.navigate(['/products']);
    } else {
      this.router.navigate(['/products'], { queryParams: { typeId } });
    }
  }

  getDeptIcon(name: string): string {
    const map: Record<string, string> = {
      'Electronics': '⚡',
      'Furniture': '🪑',
      'Stationery': '✏️',
    };
    return map[name] || '📦';
  }
}