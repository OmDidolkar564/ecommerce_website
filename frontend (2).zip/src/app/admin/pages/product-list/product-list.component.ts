import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../services/admin/admin.service';
import { ProductService } from '../../../services/product/product.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit {
  products: any[] = [];
  loading = true;
  message = '';

  constructor(
    private adminService: AdminService,
    private productService: ProductService
  ) {}

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.adminService.getProducts().subscribe({
      next: (products) => { this.products = products; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getImageUrl(imagePath: string) {
    return this.productService.getImageUrl(imagePath);
  }

  deleteProduct(id: number) {
    if (!confirm('Are you sure you want to delete this product?')) return;
    this.adminService.deleteProduct(id).subscribe({
      next: () => {
        this.message = 'Product deleted successfully';
        this.loadProducts();
      },
      error: (err) => { this.message = err.error?.message || 'Delete failed'; }
    });
  }
}